<table class="m_-9012967103479496627content" style="max-width:500px" width="100%" cellspacing="0" cellpadding="0" border="0" bgcolor="#ffffff" align="center">
<tbody>
<tr>
<td colspan="3">
<table width="100%" cellspacing="0" cellpadding="0" border="0">
<tbody>
<tr>
<td style="border-radius:4px 4px 0px 0px;"  bgcolor="#85b213" align="left">
<h3 style="color:white; padding:15px;font-family:Arial,Helvetica,sans-serif;font-size:20px; ">Contact from Imphal Angels website</h3>
</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td width="1" bgcolor="#d6d6d6">&nbsp;</td>
<td><table class="m_-9012967103479496627content_table" width="100%" cellspacing="0" cellpadding="0" border="0" align="center">
<tbody>
<tr>
<td colspan="4" height="10">&nbsp;</td>
</tr>
<tr>
<td width="24">&nbsp;</td>
<td style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#666666" colspan="2">
<p>Name: <?php echo $name; ?></p>
<p>Email: <?php echo $email;?></p>
<p>Mobile: <?php echo $phone;?></p>
</td>
<td width="26">&nbsp;</td>
</tr>
<tr>
<td colspan="4" height="0">&nbsp;</td>
</tr>
<tr>
<td width="24">&nbsp;</td>
<td style="font-family:Arial,Helvetica,sans-serif;font-size:14px;color:#666666;line-height:20px" colspan="2">
<p style="font-size:17px;">Message</p> 
<?php echo $comments; ?>  <br><br><br><br></td>
<td>&nbsp;   <br><br></td>

</tr>

<tr>
<td colspan="4">

</td>
</tr>

<tr>
<td colspan="4" height="10" bgcolor="#000">&nbsp;</td>
</tr>
<tr>
<td colspan="4" bgcolor="#000">
<table cellspacing="0" cellpadding="0" border="0" align="">
<tbody>
<tr>
<td width="15">&nbsp;</td>
<td style="font-family:Arial,Helvetica,sans-serif;font-size:12px;color:#fff;line-height:20px" colspan="2"><a style="color:#ea8a00;text-decoration:none" href="http://www.imphalangels.com/" target="_blank"><strong>www.imphalangels.com</strong></a></td>
<td width="12">&nbsp;</td>
<td width="12">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td colspan="4" height="10" bgcolor="#000">&nbsp;</td>
</tr>
</tbody>
</table>
</td>
<td width="1" bgcolor="#d6d6d6">&nbsp;</td>
</tr>

</tbody>
</table>